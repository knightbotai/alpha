#!/usr/bin/env python3
"""
Alpha Pipecat - Real-time Voice with Local Services
Uses Pipecat with Whisper, vLLM, and Kokoro from your local services.
"""
import os
import asyncio
from pipecat.pipeline import Pipeline
from pipecat.pipeline.runner import PipelineRunner
from pipecat.services import (
    OpenAILLMService,  # Will adapt for vLLM
    CartesiaTLMService,  # Will adapt for Kokoro
)
from pipecat.transports import WebRTCTransport
from pipecat.processors import (
    AudioFrameProcessor,
    LLMContext,
)
from pipecat.serializers import (
    OpenAISerializer,
)

# Local service URLs
WHISPER_URL = "http://localhost:8001"
VLLM_URL = "http://localhost:8000"
KOKORO_URL = "http://localhost:8880"


class LocalWhisperSTTService(AudioFrameProcessor):
    """Custom Whisper STT using your local service."""
    
    def __init__(self):
        super().__init__()
        self.sample_rate = 16000
    
    async def process_frame(self, frame):
        # Send audio to local Whisper
        # ... processing logic here
        yield frame


# Mode constants for state machine
MODE_CONCISE = "concise"
MODE_STORY = "story"
MODE_DEFAULT = MODE_CONCISE

class AlphaModeProcessor(AudioFrameProcessor):
    """State machine for mode switching."""
    
    def __init__(self):
        self.current_mode = MODE_DEFAULT
    
    async def handle_transcription(self, text: str):
        # Check for mode commands
        text_lower = text.lower().strip()
        
        if text_lower == "concise":
            self.current_mode = MODE_CONCISE
            return "Mode: CONCISE"
        elif text_lower == "story" or text_lower == "verbose":
            self.current_mode = MODE_STORY
            return "Mode: STORY"
        
        # Return response based on mode
        if self.current_mode == MODE_CONCISE:
            # Short, direct responses
            return make_concise_response(text)
        else:
            # Story mode - allow longer responses
            return make_story_response(text)


def make_concise_response(text: str) -> str:
    """Generate concise response."""
    return f"Got it: {text[:50]}"


def make_story_response(text: str) -> str:
    """Generate verbose story-style response."""
    return f"Let me think about {text}..."


async def main():
    print("🎙️ Alpha Pipecat - Local Services")
    print("-" * 40)
    print("Whisper:", WHISPER_URL)
    print("vLLM:", VLLM_URL)
    print("Kokoro:", KOKORO_URL)
    print("-" * 40)
    
    # Initialize services
    # stt = LocalWhisperSTTService()
    # llm = OpenAILLMService()  # Adapt for vLLM
    # tts = CartesiaTLMService()  # Adapt for Kokoro
    
    # Initialize transport
    transport = WebRTCTransport(
        "Alpha Pipecat",
        "wss://your-server/webrtc",
    )
    
    # Build pipeline
    pipeline = Pipeline([
        transport,
        # stt,
        # llm,
        # tts,
    ])
    
    # Run
    runner = PipelineRunner()
    await runner.run(pipeline)


if __name__ == "__main__":
    asyncio.run(main())